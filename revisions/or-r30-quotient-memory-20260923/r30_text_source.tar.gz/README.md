# R30 — compact allocation quotient and minimal price memory

This directory contains the R30 revision answering the price-state R29 referee report. The root `main.pdf` (22 pages) and `electronic_companion.pdf` (10 pages) are the current journal files. Start with `RESPONSE_TO_REFEREES.pdf` or `.md`, then the main manuscript. The complete prior mathematical manuscript, not only a summary, is in `predecessor/main.pdf` and `predecessor/electronic_companion.pdf`. All other historical sources and evidence remain unchanged.

## Scientific additions

The exact laminar mapping and occurrence quotient are followed by a coefficient-event rational bit-complexity theorem. A backward behavioral quotient characterizes the smallest writable implementation alphabet. A heterogeneous renewal frontier and a fixed-mean outside-option dispersion result strengthen the former crafted example. The fixed-release oracle now treats tied and singleton bounds completely. `NOVELTY_MATRIX.md` identifies classical ingredients rather than assigning scalar marginal allocation to this paper.

## Evidence and scope

`results/comparisons.json` contains 54 completed case/method workers; `results/scaling.json` contains 12. Fresh workers run sequentially with numerical thread counts fixed to one. Comparison phases have three repetitions; scale certificate/audit phases have one explicitly labeled diagnostic run. The largest public graph has 2,045 vertices. The distinct breakpoint-dense family reaches 197,369 stored segments at 511 vertices. `results/CENSORED_RUNS.json` preserves the limits of exploratory attempts.

The independent tree baseline is a specified occurrence-indexed marginal reduction, not original-author software. The generic convex solver is SciPy trust-constr, not OSQP or a commercial solver. The promise-grid baseline is a public-graph state method, not SDDP. Fraction replay certifies returned policies; floating-grid decision selection is not a claim of a globally exact arbitrary promise grid. No timings for unimplemented methods are reported.

`FINAL_VALIDATION.json` recompiles and compares every saved certificate with the final code, audits exact KKT/flow conditions, records regression tests, checks the PDFs, and verifies source preservation. Implementation verification is not a substitute for the analytic proofs. `LITERATURE_AUDIT.md` also makes clear which classical full texts were not obtained; exhaustive historical priority is not certified.

## Reproduction

Use Python 3.13 with the pinned dependencies in `requirements.txt`. The exact compiler and its independent policy auditor use the standard library; NumPy/SciPy are required for the comparison suite. The TeX build requires pdflatex, newtxtext/newtxmath, amsmath/amsthm, natbib, geometry, setspace, fancyhdr, hyperref and xr-hyper, plus pdfinfo for checks. No external service, dataset, API key, commercial license, or network call is required to run the experiments.

From the repository root:

```sh
R=revisions/or-r30-quotient-memory-20260923
python "$R/tests.py"
python "$R/experiments.py" --suite comparisons --rerun
python "$R/experiments.py" --suite scaling --rerun
python "$R/summarize.py"
bash "$R/build.sh"
python "$R/validate_final.py"
```

Omit `--rerun` to reuse matching completed worker receipts; the output then is not a newly measured timing run. Full reruns can be expensive for exact large-denominator inputs. Rerun in a copy when preserving the committed timing record matters. The largest experiment's certificates contain internally generated rational integers exceeding Python's default decimal conversion length guard; only the trusted experiment/validation entry points disable that guard. The compiler itself does not globally disable it for untrusted inputs.

## Provenance and publication status

Base commit: `51552e4198f09b82c764956b92d7b1ee2ad57aff`. Review commit: `d1f7f977132e46ac9ca582a1d78f5219365509c8`. New local branch: `revision/ndu-operations-research-r30-quotient-memory-20260923`.

The repository connection available in this session exposed read actions only, and container GitHub network access failed. Therefore this package is a **locally committed revision, not a claim of a successfully pushed remote branch**. No remote CI run is counted as R30 validation. The deliverable includes a Git bundle and binary patch so the exact branch can be imported without reconstructing edits. `IMPORT_AND_PUBLISH.md` gives guarded import/push commands. Other remote branches and main have not been modified.
