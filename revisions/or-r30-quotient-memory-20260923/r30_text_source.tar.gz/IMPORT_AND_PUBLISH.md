# Import the exact local revision and publish a new remote branch

The bundle and patch are delivered alongside the review package. The bundle represents the local branch `revision/ndu-operations-research-r30-quotient-memory-20260923` and uses scientific base `51552e4198f09b82c764956b92d7b1ee2ad57aff`. No force push or main-branch rewrite is necessary. This document describes commands to run in an authenticated clone; it does not assert they have run remotely.

In a clean clone of `TrillionniumFoundation/NDU`, first fetch the reviewed base and verify the bundle. Replace the bundle pathname with its downloaded location.

```sh
git fetch origin revision/ndu-operations-research-r29-price-state-20260923
git cat-file -e 51552e4198f09b82c764956b92d7b1ee2ad57aff^{commit}
git bundle verify /path/to/NDU_OR_R30_revision.bundle
BRANCH=revision/ndu-operations-research-r30-quotient-memory-20260923
# The destination ref must not already exist; inspect any existing work instead of overwriting it.
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  echo 'Local revision branch already exists; inspect it before importing.' >&2
  exit 1
fi
git fetch /path/to/NDU_OR_R30_revision.bundle "refs/heads/$BRANCH:refs/heads/$BRANCH"
git switch "$BRANCH"
git log -1 --format=fuller
git diff --stat 51552e4198f09b82c764956b92d7b1ee2ad57aff..HEAD
```

After inspecting the branch and optionally repeating the validation, publish only this new branch:

```sh
git push -u origin "HEAD:refs/heads/revision/ndu-operations-research-r30-quotient-memory-20260923"
```

The normal push rejects a conflicting non-fast-forward remote branch. Do not add `--force`. The original review branch and all prior revision branches remain separate. An alternative import is to create a new branch at the exact base and run `git am --binary /path/to/NDU_OR_R30.patch`; the delivered patch was replay-tested against that base. The final receipt outside the commit records the actual local commit SHA and bundle/patch hashes.
